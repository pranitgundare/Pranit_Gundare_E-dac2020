package module2;

import java.util.Scanner;

public class Question9
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the Days:");
        int days = scan.nextInt();
        
        int y= days/365;
        System.out.println("Years:"+y);
        
        int m = (days % 365) / 30;
        System.out.println("Months:"+m);
        
        int d = (days % 365) - (m * 30);
        System.out.println("Days:"+d);
        
    }
}