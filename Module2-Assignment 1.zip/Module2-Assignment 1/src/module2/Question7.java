package module2;

import java.util.Scanner;

public class Question7
{
    public static void main(String[] args)
    {
        float percentage;
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        int c = scan.nextInt();
        int d = scan.nextInt();
        int e = scan.nextInt();
        
        
        percentage = ((a+b+c+d+e)*100)/500;
        
        System.out.println("Sum of marks:"+(a+b+c+d+e));
        System.out.println("Percentage marks:"+percentage +"%");
        
        
        
        
       
    }
}