package Module2;

public class Question2
{
    public static void main(String args[])
    {
        int rollNo= 100;
        
        System.out.println("rollNo:"+rollNo);
    }
}
        