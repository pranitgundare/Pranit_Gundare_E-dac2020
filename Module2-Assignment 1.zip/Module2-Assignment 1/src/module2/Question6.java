package module2;

import java.util.Scanner;

public class Question6
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        double radius = scan.nextDouble();
        
        double area= 3.14*radius*radius;
        double circumference = 2*3.14*radius*radius;
        
        System.out.println("Area:"+area);
        System.out.println("Circumference:"+circumference);
    }
}