package module2;

import java.util.Scanner;

public class Question15
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String s = scan.next();
        int age  = scan.nextInt();
        
        if (s.equals("m"))
        {
            if(age>23)
            
                System.out.println("Person is eligible for Marriage");
            else
                System.out.println("Person is Not Eligible for Marriage"); 
            
        }
        else if(s.equals("f"))
        {
            if(age>18)
            
                System.out.println("Peraon is Eligible for marriage");
            else
                System.out.println("Person is Not Eligible for Marriage");
        }
    }
}