package module2;

import java.util.Scanner;

class java
{
    public void f(int x)
    {
       int y =x*x+3*x-7;
        System.out.println(y);
    }
    public void f1(int x)
    {
       int y =x++ + ++x;//5+7 last value of x is 7
        System.out.println("value of x:"+x);
        System.out.println("value of y:"+y);
    }
    public void f2(int x ,int y)
    {
        int z=x++ - --y - --x + x++;//5-4-5+5 last value of x is 6,last value of y is 4
        System.out.println("Value of x:"+ x);
        System.out.println("value of y:"+ y);
        System.out.println("Value of z:"+ z);
    }
    public void f3(boolean x,boolean y)
    {
        boolean z =x && y ||!(x||y);//T&&T||!(T||T)
        System.out.println(z);
    }
}
class Question3
{
    public static void main(String[]args)
    {
        System.out.println("Enter number");
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y =sc.nextInt();
        boolean z= sc.nextBoolean();
        boolean m=sc.nextBoolean();
        System.out.println("-------------------------");
        java obj = new java();
        obj.f(x);
        System.out.println("--------------------------");
        obj.f1(x);
        System.out.println("----------------------------");
        obj.f2(x,y);
        System.out.println("---------------------------------");
        obj.f3(z,m);
        
    }
}