package module2;

import java.util.Scanner;

public class Question8
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter Principal ammount:");
        float pi = scan.nextFloat();
                
        System.out.print("Enter Rate of Interest:");
        float ri = scan.nextFloat();
                
        System.out.print("Enter Time Period:");
        float time = scan.nextFloat();
        float si;
        
        si = (pi * ri * time)/100;
        
        System.out.println("Simple Interest is:"+si);
        
    }
} 