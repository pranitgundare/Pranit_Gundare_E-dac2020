package module2;

public class Question4
{
    public static void main(String[] args)
    {
        byte a= 20;
        byte b=30;
        byte c= (byte)(a+b);
        System.out.println("Addition: " +c);
    }
}