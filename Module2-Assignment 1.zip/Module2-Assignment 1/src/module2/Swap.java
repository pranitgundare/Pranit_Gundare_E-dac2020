package module2;

import java.util.Scanner;

public class Swap
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("BEFORE SWAPPING:");
        System.out.print("A:");
        int a= scan.nextInt();
        System.out.print("B:");
        int b= scan.nextInt();
        
        a = a+b;
        b = a-b;
        a = a-b;
        
        System.out.println("AFTER SWAPPING:");
        System.out.println("A:"+a);
        System.out.println("B:"+b);
        
        
    }
}