package in.edac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserAction {
	@Autowired
	UserRepository userRepo;
	@PostMapping("/")
	public boolean create(User user) {
		userRepo.save(user);
		return true;
	}
	
	@GetMapping("/{id}")
	public User getSingleUser(@PathVariable int id) {
		User user = userRepo.findById(id).get();
		return user;
	}
	@GetMapping("/")
	public List<User> gerUserAll() {
		List<User> list = userRepo.findAll();
		return list;
	}
	
	@PutMapping("/{id}")
	public boolean updateUser(@PathVariable int id,User user) {
		userRepo.save(user);
		return true;
	}
	
	@DeleteMapping("/{id}")
	public boolean deleteUser(@PathVariable int id) {
		userRepo.deleteById(id);
		return true;
	}
}
