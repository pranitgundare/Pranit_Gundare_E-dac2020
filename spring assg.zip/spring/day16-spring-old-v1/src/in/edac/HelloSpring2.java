package in.edac;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloSpring2 {
	private static final ApplicationContext contex =  new ClassPathXmlApplicationContext("spring.xml");
	public static void main(String[] args) {
		System.out.println("hello world");
		UserDao user = (UserDao)contex.getBean("obj1");
		System.out.println(user);
		UserDao user1 = (UserDao)contex.getBean("obj1");
		System.out.println(user1);
		UserDao user3 = contex.getBean("obj1",UserDao.class);
		System.out.println(user3);
		System.out.println(contex);
		
	}
	
}
