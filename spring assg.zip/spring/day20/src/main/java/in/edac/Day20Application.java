package in.edac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day20Application {

	public static void main(String[] args) {
		SpringApplication.run(Day20Application.class, args);
	}

}
