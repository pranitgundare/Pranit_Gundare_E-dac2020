package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

public class UserDao {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/project1";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public void checkconnection() throws Exception {

		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);) {
			
			System.out.println("connection successfully done!!!");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public boolean createuser(User user) throws Exception {

		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
			String sql = "INSERT INTO USER (USERNAME,EMAIL,PASSWORD,MOBILE) VALUES (?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2,user.getEmail());
			ps.setString(3,user.getPassword());
			ps.setString(4,user.getMobile());
			ps.executeUpdate();
			
			System.out.println("UserCreated successfully!!!");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("invalid entery");
			throw e;
			
		}
	}
	
	public boolean updateuser(User user) throws Exception {
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
			String sql = "UPDATE USER SET USERNAME=?,EMAIL=?,PASSWORD=?,MOBILE=? WHERE ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getEmail());
			ps.setString(3,user.getPassword());
			ps.setString(4,user.getMobile());
			ps.setInt(5,user.getId());
			ps.executeUpdate();
			System.out.println("Record update successfully");
			return true;
			
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean deleteuser(User user) throws Exception {
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
			String sql = "DELETE FROM USER WHERE ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,user.getId());
			ps.executeUpdate();
			System.out.println("Record deleted successfully");
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	} 
	
	public List<User> readRecord() throws Exception {
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
			String sql = "SELECT * FROM USER";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			List<User> list = new ArrayList<User>();
			while(rs.next()) {
				int ID1 = rs.getInt("ID");
				String USERNAME1 = rs.getString("USERNAME");
				String EMAIL1 = rs.getString("EMAIL");
				String PASSWORD1 = rs.getString("PASSWORD");
				String MOBILE1 = rs.getString("MOBILE");
				User user = new User();
				user.setId(ID1);
				user.setUsername(USERNAME1);
				user.setEmail(EMAIL1);
				user.setPassword(PASSWORD1);
				user.setMobile(MOBILE1);
				list.add(user);
				
			}
			System.out.println("Record read successfully");
			return list;
			
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public static void main(String args[]) throws Exception {
		UserDao dao = new UserDao();
		//User user = new User("pranav","pranav@gmail.com","8765","3333333333");
		//User user = new User();
		//user.checkconnection();
		//dao.createuser(user);
		//user.setId(5);
		//dao.updateuser(user);
		//user.setId(5);
		//dao.deleteuser(user);
		//List<User> list = dao.readRecord();
		//System.out.println(list.User.ID);
		
		
	}
	
}


