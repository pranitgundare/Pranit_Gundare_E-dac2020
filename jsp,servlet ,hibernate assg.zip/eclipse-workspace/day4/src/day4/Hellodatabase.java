package day4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Hellodatabase {

	// step1
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/day1library";
	public static final String DB_USERNAME = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) {
		try {

			// step2
			Class.forName(DB_DRIVER);
			// step3
			Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
			// logic
			System.out.println("connection successfully done");
			String query = "select * from books";
			PreparedStatement ps =  con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			System.out.println("Bid\tBName\tSubject");
			while(rs.next()) {
				int bId = rs.getInt("Bid");
				String bName = rs.getString("Bname");
				String subject = rs.getString("subject");
				System.out.println(bId+"\t"+bName+"\t"+subject);
			}
			// step last
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
