package day13.run;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import day13.entity.Person;
import day13.entity.Student;

public class HelloHibernate {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Student std = new Student();
		std.setName("prafulla gaikwad");
		session.save(std);
		
		Person p = new Person();
		p.setDepartment("mechanical");
		session.save(p);
		tx.commit();
		session.close();
		System.out.println("Hello world");
		
		
	}
}
