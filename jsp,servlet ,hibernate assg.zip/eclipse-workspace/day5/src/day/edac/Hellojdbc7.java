package day.edac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Hellojdbc7 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/day5";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) throws Exception {
		Connection con = null;
		try {

			Class.forName(DB_DRIVER);
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			String query = "UPDATE USER SET USERNAME='VIRAT',EMAIL='virat@gmail.com' WHERE ID=1";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.executeUpdate();
			System.out.println("updated successfully ");

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}
	}

}
