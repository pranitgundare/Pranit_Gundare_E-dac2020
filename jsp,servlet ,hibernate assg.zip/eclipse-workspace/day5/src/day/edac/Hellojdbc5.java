package day.edac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Hellojdbc5 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL ="jdbc:mysql://localhost:3306/day5";
	public static final String DB_USER ="root";
	public static final String DB_PASSWORD ="edac20";
	
	
	public static void main(String[] args) throws Exception {
		Connection con = null;
		try {
			Class.forName(DB_DRIVER);
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			
			String query = "INSERT INTO USER (USERNAME,EMAIL,PASSWORD,MOBILE) VALUES ('pranit','pranit@gmail.com','4321','123456789')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
			System.out.println("connection successfully done 4");

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
				con.close();
		}
	}

}
