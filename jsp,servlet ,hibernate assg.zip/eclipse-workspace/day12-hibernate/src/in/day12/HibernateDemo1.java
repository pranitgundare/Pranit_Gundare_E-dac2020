package in.day12;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateDemo1 {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {
		Session session = sessionFactory.openSession();	//teake connection object from pool...no creating the new connection object
		
		Transaction tx = session.beginTransaction();
		tx.commit();
		session.close();// its not distroying connection object its just keep the object return back to the connection pool
		
	}
}
