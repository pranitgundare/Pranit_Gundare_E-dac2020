package nipunsir_project;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Reflection {
	public static void main(String[] args) {
		try {
			Class cls = Class.forName("firstprogram.List");
			Field f[] = cls.getDeclaredFields();
			for(Field field : f) {
				System.out.println(field.getName());
			}
			Method[] methods = cls.getDeclaredMethods();
			for(Method method : methods) {
				System.out.println(method);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
