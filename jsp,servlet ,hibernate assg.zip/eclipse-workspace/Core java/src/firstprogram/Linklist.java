package firstprogram;

import java.util.*;

class Buddy{
	String name;
	String no;
	String emailid;
	String city;
	String dob;
	Buddy next;
	
	Buddy(String name,String no,String emailid,String city,String dob){
		this.name=name;
		this.no=no;
		this.emailid=emailid;
		this.city=city;
		this.dob=dob;
		this.next=null;
	}
	
}
class List{
	Buddy head;
	
	List(){
		this.head=null;
	}
	void insert(String name,String no,String emailid,String city,String dob) {
		Buddy bd = new Buddy(name,no,emailid,city,dob);
		if(head==null) {
			head=bd;
		}else {
			Buddy temp = head;
			while(temp.next!=null) {
				temp=temp.next;
			}
			temp.next=bd;
		}
	}
	void display() {
		if(head==null) {
			System.out.println("list is empty");
		}else {
			Buddy temp = head;
			while(temp!=null) {
				System.out.print(temp.name+" ");
				System.out.print(temp.no+" ");
				System.out.print(temp.emailid+" ");
				System.out.print(temp.city+" ");
				System.out.print(temp.dob+" ==>>");
				temp=temp.next;
			}
		}
	}
	void searchbuddy(String emailid) {
		if(head==null) {
			System.out.println("list empty");
		}else {
			Buddy temp = head;
			int flag=0;
			while(temp!=null) {
				if(temp.emailid.equals(emailid)) {
					flag=1;
					break;
				}else {
					temp=temp.next;
				}
			}
			if(flag==1) {
			System.out.print(temp.name+" ");
			System.out.print(temp.no+" ");
			System.out.print(temp.emailid+" ");
			System.out.print(temp.city+" ");
			System.out.print(temp.dob+" ==>>");
			}else {
				System.out.println("not found");
			}
		}
	}
	/*void delete(String emailid) {
		if(head==null) {
			System.out.println("list is empty");
		}else {
			if(head.emailid.equals(emailid)) {
				head=head.next;
			}else {
				Buddy temp = head;
				int flag;
				while(temp.next.next!=null) {
					if(temp.emailid.equals(emailid)) {
						flag=1;
						
					}
				}
			}
			}
		}
	}*/
}

public class Linklist {
	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		List ls = new List();
		int choice;
		do {
			System.out.println("Enter ypur choice");
			System.out.println("1=insert   2=display  3=search  0=exit");
			choice=sc.nextInt();
			
			switch(choice) {
				case 1:
					System.out.println("Enter name");
					String name=sc.next();
					System.out.println("Enter no");
					String no = sc.next();
					System.out.println("Enter emailid");
					String emailid = sc.next();
					System.out.println("Enter city");
					String city = sc.next();
					System.out.println("Enter dob");
					String dob = sc.next();
					ls.insert(name,no,emailid,city,dob);
					break;
				case 2:
					ls.display();
					System.out.println();
					break;
				case 3:
					System.out.println("Enter your emailid");
					String emailid1 = sc.next();
					ls.searchbuddy(emailid1);
					break;
			}
		}while(choice!=0);
		System.out.println("EXIT");
		//ls.insert("prafulla","9564857868","pra@gmail.com","panvel","3-3-1997");
		//ls.insert("prakash","9564857868","prf@gmail.com","panvel","3-3-1997");
		//ls.insert("gaikwad","9564857868","prp@gmail.com","panvel","3-3-1997");
		//ls.display();
		//ls.searchbuddy("prq@gmail.com");
		
	}
}
