package firstprogram;

public class Helloword2 {
	public static void main(String[] args) {
		System.out.println("prafulla gaikwad");
		
	}
}
