import java.util.Scanner;

public class HelloEx1
{
  public static void main(String[] args)
  {
     System.out.println("Hello..");
     System.out.println("\nAlexandra Abramov");  

  }


}