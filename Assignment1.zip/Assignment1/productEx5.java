import java.util.Scanner;

public class productEx5
{
  public static void main(String[] args)
  {
    int a,b,c; 
    Scanner s = new Scanner(System.in);
    
    System.out.println("Input First Number: ");
    a = s.nextInt();

    System.out.println("Input Second Number: ");
    b = s.nextInt();

    c = a*b;

    System.out.println("a*b="+c); 
  }

}