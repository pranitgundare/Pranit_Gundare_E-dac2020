import java.util.Scanner;

public class DivideEx3
{
   public static void main(String[] args)
   {
     int a=50, b=3, c;
     c =a/b;
     System.out.println("Dividation is: "+c);
   
   }

}