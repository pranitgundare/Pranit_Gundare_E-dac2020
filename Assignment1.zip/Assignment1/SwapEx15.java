import java.util.*;

public class SwapEx15
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    System.out.println("Before Swapping");        
    int a = scan.nextInt();
    int b = scan.nextInt();
    int c ;

    c = a ;
    a = b ;
    b = c ;

   System.out.println("After Swapping");
   System.out.println(" "+a);
   System.out.println(" "+b);
  }
}
    