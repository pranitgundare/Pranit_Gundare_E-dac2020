import java.util.*;

public class OctalEx21
{
  public static void main (String[] args)
  {
    int decnum, rem, quot, i=1, j;
    int o[] = new int[100];

    Scanner scan = new Scanner(System.in);
    decnum = scan.nextInt();

    quot = decnum;
  while(quot != 0)
        {
            o[i++] = quot%8;
            quot = quot/8;
        }
		
        System.out.print("Octal number is: ");
        for(j=i-1; j>0; j--)
        {
            System.out.print(o[j]);
        }
		System.out.print("\n");
    }
}