import java.util.Scanner;

public class sumoftwoEx2
{
  public static void main(String[] args)
  {
     int a=74, b=36;
     int c;
     c = a+b;
  
     System.out.println("Sum of two numbers is:"+c);
  
  }

}