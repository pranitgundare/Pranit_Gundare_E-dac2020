import java.util.*;
 

public class CircleEx11
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
     System.out.print("Enter Radius: ");
     double r = scan.nextDouble();
     double a,p;
     
     a= 3.14*r*r;
     p= 2*3.14*r;

     System.out.println("Area= "+a);
     System.out.println("perimeter= "+p);
   }
}
     