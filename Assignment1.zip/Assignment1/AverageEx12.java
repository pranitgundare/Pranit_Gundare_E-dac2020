import java.util.*;

public class AverageEx12
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    
    System.out.print("Input First Number: ");    
    int a = scan.nextInt();

    System.out.print("Input Second Number: ");
    int b = scan.nextInt();

    System.out.print("Input Third Number: ");
    int c = scan.nextInt();
    int d;

    d = (a+b+c)/3;
  
    System.out.println("Average of three numbers is: "+d);
   }
}