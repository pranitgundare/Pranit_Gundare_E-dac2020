import java.util.*;

public class BintodeciEx22
{
  public static void main(String[] args)
  {
    int bin_num, dec_num=0, j=1, rem;
    
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter Binary Number: ");
    bin_num = scan.nextInt();

    while(bin_num != 0)
    {
      rem = bin_num % 10;
      dec_num = dec_num + rem * j;
      j = j * 2;
   bin_num = bin_num / 10;
  }
  System.out.println("Decimal Number: " + dec_num);
 }
}    