import java.util.*;

public class FaceEx16 {

 public static void main(String[] args) {

  String[] arra = new String[5];

  arra[0] = " +\"\"\"\"\"+ ";
  arra[1] = "[| o o |]";
  arra[2] = " |  ^  |";
  arra[3] = " | '-' |";
  arra[4] = " +-----+";
   System.out.println("Expected Face Output: ");
  for (int i = 0; i < 5; i++) {
   System.out.println(arra[i]);
  }

 }

}