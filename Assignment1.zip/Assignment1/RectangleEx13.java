import java.util.*;

public class RectangleEx13
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    System.out.print("Input width: ");
    double width = scan.nextDouble();

    System.out.print("Input height: ");
    double height = scan.nextDouble();

    double a,p;

    a = width + height;
    p = 2* (width+height);

   System.out.println("Area is: " +a);
 
   
   System.out.println("Perimeter is: "+p);    
  }
}