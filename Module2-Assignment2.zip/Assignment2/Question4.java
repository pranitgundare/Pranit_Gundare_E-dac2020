package Assignment2;

import java.util.Scanner;

public class Question4 
{
  public static void main(String[] args)
  {
      Scanner scan = new Scanner(System.in);
      System.out.print("Input Number: ");
      int n = scan.nextInt();
     int i,sum=0;
		for(i=12;i<=n;i=i+10)
		{
			System.out.print(i);
			if(i<n)
				System.out.print("+");
			sum = sum + i;
		}
		System.out.println("\n Sum Of Series: " + sum);
  }
}

