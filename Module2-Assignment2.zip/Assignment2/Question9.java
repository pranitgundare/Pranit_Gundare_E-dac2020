package Assignment2;

import java.util.Scanner;

public class Question9
{
     static int Search(int[] arr, int key){    
        for(int i=0;i<arr.length;i++){    
            if(arr[i] == key){    
                return i;    
            }    
        }    
        return -1;    
    }    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        
        int a[] = new int[]{1,2,3,4};
        int key = 3;
        
       System.out.println(key+" is found at index: "+Search(a, key));
        
    }
}