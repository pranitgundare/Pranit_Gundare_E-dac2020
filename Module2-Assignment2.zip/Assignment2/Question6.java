package Assignment2;

import java.util.Scanner;

public class Question6
{
    public static void main(String[] args)
    {
        int i;
        int sum=0;
        Scanner scan = new Scanner(System.in);
        int a[] = new int [10];
        System.out.println("Enter any value");
        for( i=0;i<10;i++)
        {
          
          a[i]  = scan.nextInt();    
        }
        for( i=0;i<10;i++)
        {
          
            System.out.println(a[i]); 
            sum=sum+a[i];
        }
         
         
         int average;
         average=sum/10;
         
         System.out.println("Sum="+sum);
         System.out.println("Average="+average);
        
    }
}