package Assignment2;

import java.util.Scanner;

public class Question5
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Input First Number:");
        int num1 = scan.nextInt();
        System.out.print("Input Second Number:");
        int num2 = scan.nextInt();
        int flag;
        System.out.println("Prime Numbers:");
        for(int i=num1;i<=num2;i++)
        {
             flag=1;
            for(int j=2;j<=i/2;j++)
            {
                if(i%j==0)
                {
                    flag=0;
                    break;
                }
            }
            if(flag==1)
            {
                System.out.println(i);
            }
        }
    }
}