package Assignment2;

import java.util.Scanner;

public class Question2
{
 public static void main(String[]args)
{
  Scanner scan = new Scanner(System.in);
  System.out.print("Input your number:");
  int x = scan.nextInt();
  int reversed = 0;

        while(x != 0) {
            int digit = x % 10;
            reversed = reversed * 10 + digit;
            x = x/10;
        }

        System.out.println("Reversed Number: " + reversed);
}
}
