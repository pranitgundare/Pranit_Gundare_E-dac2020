package Assignment2;

import java.util.Scanner;

public class Question3
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int p = scan.nextInt();
        int flag = 0;
        for(int i = 2; i <= p/2; ++i)
        {
            // condition for nonprime number
            if(p % i == 0)
            {
                flag = 1;
                break;
            }
        }

        if (flag==0)
            System.out.println(p + " is a prime number.");
        else
            System.out.println(p + " is not a prime number.");
           
    }
}