package Assignment2;

import java.util.Scanner;

public class Question8
{
    public static void main(String[] args) {        
        //Initialize array     
        int [] arr = new int [] {5, 2, 8, 7, 1, 9, 10, 11, 13, 4};     
        //int temp = 0;    
            
        //Displaying elements of original array    
        System.out.println("Elements of original array: ");    
        for (int i = 0; i < arr.length; i++) {     
            System.out.print(arr[i] + " ");    
        }    
            
        //Sort the array in descending order    
        /*for (int i = 0; i < arr.length; i++) 
        {     
            for (int j = i+1; j < arr.length; j++) 
            {     
               if(arr[i] < arr[j]) 
               {    
                   temp = arr[i];    
                   arr[i] = arr[j];    
                   arr[j] = arr[i];    
               }     
            }     
        }    
        */    
        System.out.println();  
        System.out.println("Array in reverse order: ");  
        //Loop through the array in reverse order  
        for (int i = arr.length-1; i >= 0; i--) {  
            System.out.print(arr[i] + " ");     
        }    
    }    
}    
